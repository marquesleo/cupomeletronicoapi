﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vestillo.Core.Models
{
    public class IndicadoresFuncionario
    {
        public int PacotesCriados { get; set; }
        public int OperacoesLancadas { get; set; }
        public int PecasProduzidas { get; set; }
        public int Defeitos { get; set; }
    }
}
