﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vestillo.Core.Models
{
    public class DashVendedorLead 
    {
        public int TotalLead { get; set; }
        public int TotalLeadMes { get; set; }
        public int TotalLeadFaturado { get; set; }
    }
}
