﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vestillo.Core.Models;
using Vestillo.Core.Repositories;

namespace Vestillo.Core.Controllers
{
    public class ContadorReferenciaController : GenericController<ContadorReferencia, ContadorReferenciaRepository>
    {

    }
}
