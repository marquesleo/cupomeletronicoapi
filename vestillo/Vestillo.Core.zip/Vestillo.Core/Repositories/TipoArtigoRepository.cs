﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vestillo.Core.Models;

namespace Vestillo.Core.Repositories
{
    public class TipoArtigoRepository : GenericRepository<TipoArtigo>
    {

    }
}
